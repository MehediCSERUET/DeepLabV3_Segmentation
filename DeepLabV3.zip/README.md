# Results
![](outputs/american-football-player-uniform-helmet-athlete-159776.png)
![](outputs/fashion-man-person-model.png)
![](outputs/pexels-photo-845434.png)
![](outputs/pexels-photo-175697_eZolmqmVLk.png)

### Pretrained Weights
Pretrained weights are added to the repository.
